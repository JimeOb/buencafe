// A javascript-enhanced crossword puzzle [c] Jesse Weisbeck, MIT/GPL 
(function($) {
	$(function() {
		// provide crossword entries in an array of objects like the following example
		// Position refers to the numerical order of an entry. Each position can have 
		// two entries: an across entry and a down entry
		var puzzleData = [
			 	{
					clue: "Zona de las manos que podrían llegar a convertirse en un vehículo de microbios y bacterias, si se encuentran sucias, por eso siempre se deben tener… (2 palabras)",
					answer: "uñaslimpias",
					position: 1,
					orientation: "across",
					startx: 1,
					starty: 3
				},
				{
					clue: "Hábito que permite sentir tu cuerpo limpio cada día. (2 palabras)",
					answer: "bañodiario",
					position: 1,
					orientation: "down",
					startx: 2,
					starty: 1
				},
				{
					clue: "Es una política de Higiene en Buencafé Liofilizado de Colombia (3 palabras)",
					answer: "lavadodemanos",
					position: 2,
					orientation: "down",
					startx: 5,
					starty: 3
				},
				{
					clue: "Introducción de sustancias químicas, microorganismos, u otros materiales en un alimento, que provocan que éste sea inseguro o no apto para su consumo.",
					answer: "contaminacion",
					position: 2,
					orientation: "across",
					startx: 4,
					starty: 8
				},
				{
					clue: "Probabilidad de que un peligro cause daño.",
					answer: "riesgo",
					position: 3,
					orientation: "down",
					startx: 10,
					starty: 7
				},
				{
					clue: "Estado en que un ser u organismo vivo no tiene ninguna lesión ni padece ninguna enfermedad y ejerce con normalidad todas sus funciones.",
					answer: "salud",
					position: 3,
					orientation: "across",
					startx: 5,
					starty: 15
				},
				{
					clue: "Aquel que compra productos para su consumo.",
					answer: "consumidor",
					position: 4,
					orientation: "down",
					startx: 15,
					starty: 7
				},
				{
					clue: "Ser vivo microscópico que puede causar enfermedad o lesión.",
					answer: "microorganismo",
					position: 4,
					orientation: "across",
					startx: 11,
					starty: 15
				},
				{
					clue: "Enfermedad infecciosa del tracto respiratorio.",
					answer: "gripa",
					position: 5,
					orientation: "down",
					startx: 18,
					starty: 15
				},
				{
					clue: "Rama de las Ciencias Médicas cuyo objetivo es preservar la salud a través de la limpieza.",
					answer: "higiene",
					position: 6,
					orientation: "down",
					startx: 12,
					starty: 14
				}
			] 
	
		$('#puzzle-wrapper').crossword(puzzleData);
		
	})
	
})(jQuery)
